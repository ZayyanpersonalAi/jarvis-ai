"use client";
// Jarvis voice hook — OpenAI Realtime (WebRTC) + Demo fallback (Web Speech API).
// Voice understands Urdu script, Roman Urdu and English:
// speech recognition always uses ur-PK (it handles Urdu + mixed English),
// and replies are spoken in the same language the user spoke.
// Without OPENAI_API_KEY: demo mode — browser speech recognition + /api/chat,
// answers spoken via Web Speech Synthesis. The UI shows "Demo Mode" clearly.
import { useCallback, useEffect, useRef, useState } from "react";
import { useVoiceStore } from "@/store/voice";
import type { Language, VoiceStatus } from "@/types";

interface SpeechRecognitionLike { lang: string; interimResults: boolean; continuous: boolean; onresult: ((e: { results: { transcript: string }[][] }) => void) | null; onend: (() => void) | null; onerror: ((e: unknown) => void) | null; start: () => void; stop: () => void; }

const URDU_SCRIPT = /[\u0600-\u06FF\u0750-\u077F\uFB50-\uFDFF\uFE70-\uFEFF]/;
const ROMAN_URDU_WORDS = /\b(karo|kar|kya|hai|hain|mujhe|mera|meri|batao|dikhao|bhejo|yaad|waqt|aaj|kal|tareekh|mausam|hisaab|tarjuma|kholo|band|awaz|shukriya|salam|madad|chahiye|kaise|kaisa|kahan|kab|kyun|nahi|acha|theek)\b/i;

/** Detect the language the user spoke: Urdu script or Roman Urdu -> "ur", else "en". */
export function detectSpokenLanguage(text: string): Language {
  if (URDU_SCRIPT.test(text) || ROMAN_URDU_WORDS.test(text)) return "ur";
  return "en";
}

export function useRealtimeVoice() {
  // Separate selectors — taking the whole store re-runs this hook on every
  // small change and swaps the callbacks, which re-runs VoiceAssistant's
  // useEffect again and again (infinite loop).
  const status = useVoiceStore((s) => s.status);
  const isDemo = useVoiceStore((s) => s.isDemo);
  const setStatus = useVoiceStore((s) => s.setStatus);
  const setDemo = useVoiceStore((s) => s.setDemo);
  const addMessage = useVoiceStore((s) => s.addMessage);
  const setTranscript = useVoiceStore((s) => s.setTranscript);
  const [error, setError] = useState<string | null>(null);
  const pcRef = useRef<RTCPeerConnection | null>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const streamRef = useRef<MediaStream | null>(null);
  const recordingRef = useRef(false);
  const recRef = useRef<SpeechRecognitionLike | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const speakReply = useCallback((text: string) => {
    try {
      const synth = window.speechSynthesis;
      synth.cancel();
      const u = new SpeechSynthesisUtterance(text);
      // Speak in the reply's language: Urdu voice for Urdu, English voice for English.
      const lang: Language = detectSpokenLanguage(text);
      u.lang = lang === "ur" ? "ur-PK" : "en-US";
      try { const c = JSON.parse(localStorage.getItem("jarvis-memory-v1") || "{}") as { character?: string }; u.rate = c.character === "friend" ? 1.05 : c.character === "mentor" ? 0.95 : 1.0; } catch { u.rate = 0.95; }
      synth.speak(u);
    } catch { /* no speech synthesis */ }
  }, []);

  const sendText = useCallback(async (text: string) => {
    const lang = detectSpokenLanguage(text);
    setStatus("thinking");
    addMessage({ id: `u-${Date.now()}`, role: "user", text, language: lang, createdAt: new Date().toISOString() });
    try {
      const mem = JSON.parse(localStorage.getItem("jarvis-memory-v1") || "{}") as { userName?: string; interests?: string[]; facts?: { text: string }[]; chatSummary?: string; character?: string };
      const res = await fetch("/api/chat", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ message: text, language: lang, memory: mem }) });
      const j = await res.json();
      let reply: string = j?.reply || j?.data?.reply || "Sorry, I did not get a reply.";
      setDemo(Boolean(j?.demo ?? j?.data?.demo ?? false));
      // PC command: Vercel server user ke PC tak nahi pohanch sakta — is liye
      // browser/desktop khud seedha local PC agent (127.0.0.1) ko bhejta hai.
      if (j?.toolUsed === "pc_command" || j?.data?.toolUsed === "pc_command") {
        try {
          const token = localStorage.getItem("jarvis-pc-token") || "";
          const lr = await fetch("http://127.0.0.1:8787/command", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ text, token }) });
          const lj = await lr.json();
          if (lj?.message) reply = String(lj.message);
        } catch { /* agent band hai — server wala jawab hi rahega */ }
      }
      addMessage({ id: `a-${Date.now()}`, role: "assistant", text: reply, language: lang, createdAt: new Date().toISOString(), toolUsed: j?.toolUsed || j?.data?.toolUsed });
      setStatus("speaking");
      speakReply(reply);
      setStatus("idle");
    } catch {
      setStatus("error");
      setError("No reply — could not reach /api/chat.");
    }
  }, [addMessage, setStatus, setDemo, speakReply]);

  const startDemoListening = useCallback(() => {
    const w = window as unknown as { SpeechRecognition?: new () => SpeechRecognitionLike; webkitSpeechRecognition?: new () => SpeechRecognitionLike };
    const Ctor = w.SpeechRecognition || w.webkitSpeechRecognition;
    if (!Ctor) { setError("Your browser does not support voice recognition — try typing instead."); setStatus("error"); return; }
    const rec = new Ctor();
    // Always ur-PK: it understands Urdu, Roman Urdu and mixed English.
    rec.lang = "ur-PK";
    rec.interimResults = true;
    rec.continuous = false;
    rec.onresult = (e) => {
      const transcript = Array.from(e.results).map((r) => r[0]?.transcript || "").join(" ");
      setTranscript(transcript);
      if ((e.results[e.results.length - 1] as unknown as { isFinal?: boolean })?.isFinal) { rec.stop(); void sendText(transcript); }
    };
    rec.onend = () => { if (useVoiceStore.getState().status === "listening") setStatus("idle"); };
    rec.onerror = (e) => {
      // Mic blocked / no-speech / not-allowed — clear English message, status back to idle
      // so "Error" does not get stuck. The usual cause is browser mic permission.
      const kind = (e as { error?: string })?.error || "";
      setError(kind === "not-allowed" || kind === "service-not-allowed"
        ? "Microphone permission was not given — allow the mic in your browser, then try again."
        : "No voice came through the mic — press the mic again, or type below instead.");
      setStatus("idle");
    };
    recRef.current = rec;
    setStatus("listening");
    rec.start();
  }, [sendText, setStatus, setTranscript]);

  // LIVE voice (Gemini): mic recording -> Gemini transcription -> Gemini chat
  // reply -> awaaz. Chrome aur desktop (Electron) app dono me chalta hai,
  // Web Speech API ki zaroorat nahi. Ye asal live pipeline hai, demo nahi.
  const startGeminiListening = useCallback(async () => {
    try {
      if (recordingRef.current) return;
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;
      const mime = ["audio/webm", "audio/mp4", "audio/ogg", ""].find((m) => m === "" || (typeof MediaRecorder !== "undefined" && MediaRecorder.isTypeSupported(m))) || "";
      const rec = mime ? new MediaRecorder(stream, { mimeType: mime }) : new MediaRecorder(stream);
      chunksRef.current = [];
      rec.ondataavailable = (e) => { if (e.data && e.data.size) chunksRef.current.push(e.data); };
      rec.onstop = () => {
        recordingRef.current = false;
        streamRef.current?.getTracks().forEach((tr) => tr.stop());
        const blob = new Blob(chunksRef.current, { type: rec.mimeType || "audio/webm" });
        if (!blob.size) { setStatus("idle"); return; }
        setStatus("thinking");
        const reader = new FileReader();
        reader.onloadend = () => {
          const base64 = String(reader.result || "").split(",")[1] || "";
          void (async () => {
            try {
              const res = await fetch("/api/transcribe", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ audio: base64, mimeType: blob.type }) });
              const j = await res.json();
              if (res.ok && j?.text) { setTranscript(j.text); await sendText(j.text); }
              else { setError("Voice samajh nahi ayi — dobara bol kar dekhein, ya type kar lein."); setStatus("idle"); }
            } catch { setError("Voice server tak nahi pohanchi — internet check karein."); setStatus("idle"); }
          })();
        };
        reader.readAsDataURL(blob);
      };
      recorderRef.current = rec;
      recordingRef.current = true;
      setError(null);
      setStatus("listening");
      rec.start();
    } catch {
      // Mic nahi mila / permission nahi — akhri fallback Web Speech (sirf Chrome)
      startDemoListening();
    }
  }, [sendText, setError, setStatus, setTranscript]);

  const startLive = useCallback(async () => {
    setError(null);
    try {
      const res = await fetch("/api/realtime/session", { method: "POST" });
      const j = await res.json();
      if (!res.ok || !j?.client_secret) {
        // OpenAI Realtime nahi — LIVE Gemini voice pipeline
        void startGeminiListening();
        return;
      }
      setDemo(false);
      const pc = new RTCPeerConnection();
      pcRef.current = pc;
      const audioEl = document.createElement("audio");
      audioEl.autoplay = true;
      audioRef.current = audioEl;
      pc.ontrack = (e) => { audioEl.srcObject = e.streams[0]; };
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach((t) => pc.addTrack(t, stream));
      const dc = pc.createDataChannel("oai-events");
      dc.onmessage = (e) => {
        try {
          const evt = JSON.parse(e.data as string) as { type?: string; transcript?: string; delta?: string };
          if (evt.type === "response.audio_transcript.done" && evt.transcript) {
            addMessage({ id: `a-${Date.now()}`, role: "assistant", text: evt.transcript, language: detectSpokenLanguage(evt.transcript), createdAt: new Date().toISOString() });
          }
          if (evt.type === "conversation.item.input_audio_transcription.completed" && evt.transcript) setTranscript(evt.transcript);
        } catch { /* ignore */ }
      };
      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      const sdpRes = await fetch(`https://api.openai.com/v1/realtime?model=gpt-4o-realtime-preview`, {
        method: "POST", headers: { Authorization: `Bearer ${j.client_secret}`, "Content-Type": "application/sdp" }, body: offer.sdp,
      });
      const answer = { type: "answer" as RTCSdpType, sdp: await sdpRes.text() };
      await pc.setRemoteDescription(answer);
      setStatus("listening");
    } catch {
      void startGeminiListening();
    }
  }, [addMessage, setDemo, setStatus, setTranscript, startGeminiListening]);

  const stop = useCallback(() => {
    if (recordingRef.current && recorderRef.current) {
      try { recorderRef.current.stop(); } catch { /* ignore */ }
      return; // onstop transcription + reply sambhal lega
    }
    try { recRef.current?.stop(); } catch { /* ignore */ }
    try { window.speechSynthesis?.cancel(); } catch { /* ignore */ }
    if (pcRef.current) { pcRef.current.getSenders().forEach((s) => s.track?.stop()); pcRef.current.close(); pcRef.current = null; }
    setStatus("idle");
  }, [setStatus]);

  useEffect(() => () => { try { recRef.current?.stop(); } catch { /* ignore */ } }, []);

  return { status: status as VoiceStatus, error, isDemo, setDemo, startLive, startGeminiListening, startDemoListening, stop, sendText, speakUrdu: speakReply };
}
