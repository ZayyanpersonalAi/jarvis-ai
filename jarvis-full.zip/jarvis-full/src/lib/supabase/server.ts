import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";
export function createServerSupabaseClient() {
  const cookieStore = cookies();
  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL || "https://placeholder.supabase.co",
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "placeholder-anon-key",
    { cookies: { getAll: () => cookieStore.getAll(), setAll: (c: { name: string; value: string; options?: Record<string, unknown> }[]) => { try { c.forEach(({ name, value, options }) => cookieStore.set(name, value, options as never)); } catch { /* read-only */ } } } }
  );
}
